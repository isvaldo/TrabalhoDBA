package br.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Cabo {
	
	@Id
	public Long id;
	public Integer tamanho;
	@OneToOne
	public TipoCabo tipo_entrada;
	@OneToOne
	public TipoCabo tipo_saida;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getTamanho() {
		return tamanho;
	}
	public void setTamanho(Integer tamanho) {
		this.tamanho = tamanho;
	}
	public TipoCabo getTipo_entrada() {
		return tipo_entrada;
	}
	public void setTipo_entrada(TipoCabo tipo_entrada) {
		this.tipo_entrada = tipo_entrada;
	}
	public TipoCabo getTipo_saida() {
		return tipo_saida;
	}
	public void setTipo_saida(TipoCabo tipo_saida) {
		this.tipo_saida = tipo_saida;
	}
	
	
	
}

package br.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Funcionario {

	@Id
	public Long id;
	public String nome;
	public String cpf;
	public Date nascimento;
	
	@OneToOne
	public FaixaSalarial salario;
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public Date getNascimento() {
		return nascimento;
	}
	public void setNascimento(Date nascimento) {
		this.nascimento = nascimento;
	}
	public FaixaSalarial getSalario() {
		return salario;
	}
	public void setSalario(FaixaSalarial salario) {
		this.salario = salario;
	}
	
	
	
}

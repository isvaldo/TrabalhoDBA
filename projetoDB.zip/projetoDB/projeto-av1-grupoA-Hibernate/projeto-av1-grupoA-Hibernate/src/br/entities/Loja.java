package br.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;


@Entity
public class Loja {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public Long id;
	public String endereco;
	
	@OneToOne
	public Estado estado;
	@ManyToMany
	public List<Funcionario> funcionario;
	@ManyToMany
	public List<Cabo> cabo;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public List<Funcionario> getFuncionario() {
		return funcionario;
	}
	public void setFuncionario(List<Funcionario> funcionario) {
		this.funcionario = funcionario;
	}
	public List<Cabo> getCabo() {
		return cabo;
	}
	public void setCabo(List<Cabo> cabo) {
		this.cabo = cabo;
	}
	
	
	
	
}

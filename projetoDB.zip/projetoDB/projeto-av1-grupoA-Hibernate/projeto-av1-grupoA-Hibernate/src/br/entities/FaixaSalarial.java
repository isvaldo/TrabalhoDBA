package br.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FaixaSalarial {

	@Id
	public Long id;
	public Long salario;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSalario() {
		return salario;
	}
	public void setSalario(Long salario) {
		this.salario = salario;
	}
	
	
}

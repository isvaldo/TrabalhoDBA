package br.entities;

import javax.persistence.Query;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dao db = new Dao();
		// Query Estilo Hibernate, nome da tabela = nome da classe
		Query createQuery = db.getConnection().createQuery("from Loja");
		
		System.out.print("foi");

	}

}

## Modelagem utilizada

Vamos construir aqui os modelos e debater sua utilização

##Diagrama de classe
![diagrama de classes](https://github.com/GADS2014M/projeto-av1-grupoA/blob/master/UML/diagramac.jpg)

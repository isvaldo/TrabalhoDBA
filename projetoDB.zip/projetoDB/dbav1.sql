-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 15/03/2016 às 18:07
-- Versão do servidor: 5.5.44-0ubuntu0.14.04.1
-- Versão do PHP: 5.5.9-1ubuntu4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de dados: `dbav1`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `Cabo`
--

CREATE TABLE IF NOT EXISTS `Cabo` (
  `id` bigint(20) NOT NULL,
  `tamanho` int(11) DEFAULT NULL,
  `tipo_entrada_id` bigint(20) DEFAULT NULL,
  `tipo_saida_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1FED4B454C89FC` (`tipo_entrada_id`),
  KEY `FK1FED4B56525DDB` (`tipo_saida_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Estado`
--

CREATE TABLE IF NOT EXISTS `Estado` (
  `id` bigint(20) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `FaixaSalarial`
--

CREATE TABLE IF NOT EXISTS `FaixaSalarial` (
  `id` bigint(20) NOT NULL,
  `salario` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Funcionario`
--

CREATE TABLE IF NOT EXISTS `Funcionario` (
  `id` bigint(20) NOT NULL,
  `cpf` varchar(255) DEFAULT NULL,
  `nascimento` datetime DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `salario_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB3A9C5BBFB96CE72` (`salario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Loja`
--

CREATE TABLE IF NOT EXISTS `Loja` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `endereco` varchar(255) DEFAULT NULL,
  `estado_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK243A1AD10B949` (`estado_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Loja_Cabo`
--

CREATE TABLE IF NOT EXISTS `Loja_Cabo` (
  `Loja_id` bigint(20) NOT NULL,
  `cabo_id` bigint(20) NOT NULL,
  KEY `FKA128AC50956DEEE9` (`cabo_id`),
  KEY `FKA128AC5089D88889` (`Loja_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Loja_Funcionario`
--

CREATE TABLE IF NOT EXISTS `Loja_Funcionario` (
  `Loja_id` bigint(20) NOT NULL,
  `funcionario_id` bigint(20) NOT NULL,
  KEY `FK61820716B938CFEB` (`funcionario_id`),
  KEY `FK6182071689D88889` (`Loja_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `TipoCabo`
--

CREATE TABLE IF NOT EXISTS `TipoCabo` (
  `id` bigint(20) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `Cabo`
--
ALTER TABLE `Cabo`
  ADD CONSTRAINT `FK1FED4B56525DDB` FOREIGN KEY (`tipo_saida_id`) REFERENCES `TipoCabo` (`id`),
  ADD CONSTRAINT `FK1FED4B454C89FC` FOREIGN KEY (`tipo_entrada_id`) REFERENCES `TipoCabo` (`id`);

--
-- Restrições para tabelas `Funcionario`
--
ALTER TABLE `Funcionario`
  ADD CONSTRAINT `FKB3A9C5BBFB96CE72` FOREIGN KEY (`salario_id`) REFERENCES `FaixaSalarial` (`id`);

--
-- Restrições para tabelas `Loja`
--
ALTER TABLE `Loja`
  ADD CONSTRAINT `FK243A1AD10B949` FOREIGN KEY (`estado_id`) REFERENCES `Estado` (`id`);

--
-- Restrições para tabelas `Loja_Cabo`
--
ALTER TABLE `Loja_Cabo`
  ADD CONSTRAINT `FKA128AC5089D88889` FOREIGN KEY (`Loja_id`) REFERENCES `Loja` (`id`),
  ADD CONSTRAINT `FKA128AC50956DEEE9` FOREIGN KEY (`cabo_id`) REFERENCES `Cabo` (`id`);

--
-- Restrições para tabelas `Loja_Funcionario`
--
ALTER TABLE `Loja_Funcionario`
  ADD CONSTRAINT `FK6182071689D88889` FOREIGN KEY (`Loja_id`) REFERENCES `Loja` (`id`),
  ADD CONSTRAINT `FK61820716B938CFEB` FOREIGN KEY (`funcionario_id`) REFERENCES `Funcionario` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
